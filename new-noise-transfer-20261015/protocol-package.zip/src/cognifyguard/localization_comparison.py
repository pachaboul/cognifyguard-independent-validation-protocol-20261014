"""Exact-tie-aware localization diagnostics; injected targets are not expert truth."""

import numpy as np

MODALITIES = ("acc", "bvp", "eda", "temp")
POLICIES = ("quality_only", "influence_only", "quality_influence")


def localization_scores(row, policy):
    if policy == "quality_only":
        scores = [1 - float(row[m + "_quality"]) for m in MODALITIES]
    elif policy == "influence_only":
        scores = [float(row[m + "_influence"]) for m in MODALITIES]
    elif policy == "quality_influence":
        scores = [float(row[m + "_interaction"]) for m in MODALITIES]
    else:
        raise ValueError("Unknown localization policy")
    result = np.asarray(scores)
    if not np.isfinite(result).all() or np.any(result < 0):
        raise ValueError("Invalid modality scores")
    return result


def top_score_metrics(scores, target):
    scores = np.asarray(scores, float)
    if scores.shape != (4,) or not np.isfinite(scores).all() or np.any(scores < 0):
        raise ValueError("Expected four nonnegative finite modality scores")
    if target not in MODALITIES:
        raise ValueError("Unknown target modality")
    ties = np.flatnonzero(scores == scores.max())
    correct = MODALITIES.index(target) in ties
    resolved = len(ties) == 1 and scores.max() > 0
    return {"expected_top1": float(correct) / len(ties),
            "strict_correct": float(resolved and correct),
            "resolved": float(resolved), "top_tied": float(len(ties) > 1),
            "all_zero": float(scores.max() == 0)}


def prediction_transition(label, clean_prediction, corrupted_prediction):
    values = (label, clean_prediction, corrupted_prediction)
    if any(v not in (0, 1, 2) for v in values):
        raise ValueError("Expected three-class labels and predictions")
    clean_correct = clean_prediction == label
    corrupted_correct = corrupted_prediction == label
    if clean_correct:
        return "correct_to_correct" if corrupted_correct else "correct_to_wrong"
    return "wrong_to_correct" if corrupted_correct else "wrong_to_wrong"
