from __future__ import annotations

from collections import defaultdict
from statistics import median

import numpy as np

from .contracts import ModalityQuality


def validate_quality_threshold_protocol(protocol: dict) -> list[str]:
    """Return preregistration problems without fitting or inspecting outcomes."""
    problems = []
    aggregation = protocol.get("aggregation", {})
    quantile = aggregation.get("participant_quantile")
    if not isinstance(quantile, (int, float)) or not 0 < quantile < 1:
        problems.append("participant_quantile must lie strictly between zero and one")
    if aggregation.get("across_participants") != "median":
        problems.append("participant-equal aggregation must use the frozen median")
    leakage = protocol.get("leakage_policy", {})
    for key in (
        "training_participants_only",
        "validation_participants_forbidden_for_fitting",
        "test_participants_forbidden_for_fitting",
    ):
        if leakage.get(key) is not True:
            problems.append(f"leakage policy must set {key}=true")
    application = protocol.get("bound_application", {})
    if application.get("modality_score") != "one_minus_max_indicator_severity":
        problems.append("modality score formula is not frozen")
    replacement = protocol.get("replacement_rule", {})
    if replacement.get("outer_test_use") != "final_locked_evaluation_only":
        problems.append("learned replacement may not use outer-test data for selection")
    if replacement.get("replacement_requires_protocol_amendment_before_outer_test") is not True:
        problems.append("learned replacement requires a pre-test protocol amendment")
    indicators = protocol.get("indicators", {})
    if set(indicators) != {"eda", "bvp", "temp", "acc"}:
        problems.append("indicator registry must cover exactly eda, bvp, temp, and acc")
    if any(not settings.get("upper") for settings in indicators.values()):
        problems.append("every modality must define at least one upper-bound indicator")
    return problems


def fit_participant_equal_upper_bounds(
    rows: list[dict],
    training_participants: set[str],
    indicators_by_modality: dict[str, list[str]],
    quantile: float = 0.99,
) -> dict[str, dict[str, float]]:
    if not 0 < quantile < 1:
        raise ValueError("quantile must be strictly between zero and one")
    observed = {row["participant_id"] for row in rows}
    missing = training_participants - observed
    if missing:
        raise ValueError(f"training participants missing from indicators: {sorted(missing)}")

    grouped = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
    for row in rows:
        participant = row["participant_id"]
        if participant not in training_participants:
            continue
        modality = row["modality"]
        for indicator in indicators_by_modality.get(modality, []):
            source_name = indicator.removeprefix("absolute_")
            raw_value = row.get(source_name)
            if raw_value in (None, ""):
                continue
            value = float(raw_value)
            if np.isfinite(value):
                grouped[modality][indicator][participant].append(
                    abs(value) if indicator.startswith("absolute_") else value
                )

    bounds = {}
    for modality, indicator_groups in grouped.items():
        bounds[modality] = {}
        for indicator, participant_values in indicator_groups.items():
            participant_quantiles = [
                float(np.quantile(values, quantile))
                for values in participant_values.values() if values
            ]
            if len(participant_quantiles) != len(training_participants):
                raise ValueError(f"incomplete {modality}/{indicator} participant coverage")
            bounds[modality][indicator] = float(median(participant_quantiles))
    return bounds


def assert_fit_uses_training_only(fold: dict, fitting_participants: set[str]) -> None:
    train = set(fold["train"])
    forbidden = set(fold["validation"]) | set(fold["test"])
    if fitting_participants != train:
        raise ValueError("fitting participants do not exactly match the frozen training split")
    overlap = fitting_participants & forbidden
    if overlap:
        raise ValueError(f"validation/test leakage detected: {sorted(overlap)}")


def score_modality_quality(
    modality: str,
    indicators: dict[str, float] | None,
    upper_bounds: dict[str, float],
    *,
    epsilon: float = 1e-12,
) -> ModalityQuality:
    if indicators is None:
        return ModalityQuality(modality, 0.0, "unavailable", {}, ("unavailable",))

    severities = {}
    for indicator, bound in upper_bounds.items():
        source_name = indicator.removeprefix("absolute_")
        value = indicators.get(source_name)
        if value is None or not np.isfinite(value):
            continue
        value = abs(float(value)) if indicator.startswith("absolute_") else float(value)
        bound = float(bound)
        if value <= bound:
            severity = 0.0
        elif abs(bound) <= epsilon:
            severity = 1.0
        else:
            severity = min(1.0, max(0.0, (value - bound) / abs(bound)))
        severities[indicator] = severity

    if not severities:
        return ModalityQuality(modality, 0.0, "unavailable", {}, ("no_valid_indicators",))
    exceeded = tuple(sorted(name for name, value in severities.items() if value > 0))
    score = 1.0 - max(severities.values())
    return ModalityQuality(
        modality=modality,
        score=float(np.clip(score, 0.0, 1.0)),
        status="degraded" if exceeded else "present",
        indicator_severity=severities,
        exceeded_indicators=exceeded,
    )


def ablate_quality_indicator(
    quality: ModalityQuality, excluded_indicator: str
) -> ModalityQuality:
    """Recompute max-severity quality after removing one indicator."""
    if excluded_indicator not in quality.indicator_severity:
        raise ValueError(f"indicator is absent from quality evidence: {excluded_indicator}")
    remaining = {
        name: float(value)
        for name, value in quality.indicator_severity.items()
        if name != excluded_indicator
    }
    if not remaining:
        raise ValueError("indicator ablation cannot remove the only quality indicator")
    exceeded = tuple(sorted(name for name, value in remaining.items() if value > 0))
    return ModalityQuality(
        modality=quality.modality,
        score=float(np.clip(1.0 - max(remaining.values()), 0.0, 1.0)),
        status="degraded" if exceeded else "present",
        indicator_severity=remaining,
        exceeded_indicators=exceeded,
    )
