"""Quality-only designed-regime features and explicitly abstaining assertions."""
import numpy as np

from .localization_comparison import MODALITIES


def quality_features(qualities):
    deficits = np.array([1 - float(qualities[m]) for m in MODALITIES])
    if not np.isfinite(deficits).all() or np.any((deficits < 0) | (deficits > 1)):
        raise ValueError("Quality must be finite and in [0, 1]")
    ordered = sorted(deficits, reverse=True)
    total = deficits.sum()
    positive = deficits[deficits > 0]
    entropy = float(-np.sum((positive / total) * np.log(positive / total)) / np.log(4)) if total else 0.
    return np.r_[deficits, ordered[:2], total, entropy]


def unique_positive_assertion(scores):
    scores = np.asarray(scores, float)
    if scores.shape != (4,) or not np.isfinite(scores).all() or np.any(scores < 0):
        raise ValueError("Expected four finite nonnegative scores")
    top = np.flatnonzero(scores == scores.max())
    return MODALITIES[int(top[0])] if len(top) == 1 and scores.max() > 0 else ""
