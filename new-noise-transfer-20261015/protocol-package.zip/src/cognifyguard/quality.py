from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .backbone import MODALITY_ORDER
from .thresholds import score_modality_quality


@dataclass(frozen=True)
class QualityAssessment:
    score: float
    failures: tuple[str, ...]
    indicators: dict[str, float]


def describe_device_bounds(values, *, lower: float, upper: float,
                           rail_tolerance: float = 0.0) -> dict[str, float]:
    """Describe occupancy relative to documented device bounds.

    These descriptors report acquisition-domain behavior only. They do not
    classify values as physiologically plausible or clinically meaningful.
    """
    if lower >= upper:
        raise ValueError("lower must be smaller than upper")
    if rail_tolerance < 0:
        raise ValueError("rail_tolerance must be non-negative")
    flat = np.asarray(values, dtype=float).reshape(-1)
    finite = flat[np.isfinite(flat)]
    if finite.size == 0:
        return {
            "below_device_range_ratio": float("nan"),
            "above_device_range_ratio": float("nan"),
            "lower_rail_ratio": float("nan"),
            "upper_rail_ratio": float("nan"),
        }
    return {
        "below_device_range_ratio": float(np.mean(finite < lower)),
        "above_device_range_ratio": float(np.mean(finite > upper)),
        "lower_rail_ratio": float(np.mean(np.abs(finite - lower) <= rail_tolerance)),
        "upper_rail_ratio": float(np.mean(np.abs(finite - upper) <= rail_tolerance)),
    }


def _longest_constant_run_ratio(values: np.ndarray) -> float:
    channels = values.reshape(len(values), -1)
    longest = 1
    for channel in channels.T:
        if len(channel) < 2:
            continue
        run = 1
        for unchanged in np.diff(channel) == 0:
            run = run + 1 if unchanged else 1
            longest = max(longest, run)
    return longest / max(1, len(values))


def _pearson_or_nan(left: np.ndarray, right: np.ndarray) -> float:
    size = min(len(left), len(right))
    left, right = left[:size], right[:size]
    finite = np.isfinite(left) & np.isfinite(right)
    left, right = left[finite], right[finite]
    if len(left) < 3 or np.std(left) == 0 or np.std(right) == 0:
        return float("nan")
    return float(np.corrcoef(left, right)[0, 1])


def describe_multimodal_window(modalities: dict[str, np.ndarray]) -> dict[str, dict[str, float]]:
    """Return modality-aware descriptors without applying quality thresholds."""
    result: dict[str, dict[str, float]] = {}
    for modality, values in modalities.items():
        x = np.asarray(values, dtype=float)
        flat = x.reshape(-1)
        finite = flat[np.isfinite(flat)]
        if finite.size:
            minimum, maximum = np.min(finite), np.max(finite)
            rail_occupancy = float(np.mean((finite == minimum) | (finite == maximum)))
        else:
            rail_occupancy = float("nan")
        result[modality] = {
            "rail_occupancy_ratio": rail_occupancy,
            "longest_constant_run_ratio": _longest_constant_run_ratio(x),
            "motion_coupling": float("nan"),
            "acc_magnitude_std": float("nan"),
            "acc_jerk_median": float("nan"),
        }

    acc = np.asarray(modalities["acc"], dtype=float).reshape(-1, 3)
    magnitude = np.linalg.norm(acc, axis=1)
    acc_activity_4hz = np.asarray([
        np.std(block) for block in np.array_split(magnitude, 40)
    ])
    result["acc"]["acc_magnitude_std"] = float(np.std(magnitude))
    result["acc"]["acc_jerk_median"] = float(np.median(np.abs(np.diff(magnitude))))

    for modality, native_hz in (("eda", 4), ("bvp", 64), ("temp", 4)):
        signal = np.asarray(modalities[modality], dtype=float).reshape(-1)
        block_size = native_hz // 4
        if block_size > 1:
            variation = np.asarray([
                np.median(np.abs(np.diff(signal[index:index + block_size])))
                for index in range(0, len(signal), block_size)
            ])
        else:
            variation = np.abs(np.diff(signal, prepend=signal[0]))
        result[modality]["motion_coupling"] = _pearson_or_nan(
            acc_activity_4hz, variation
        )
    return result


def score_multimodal_quality(modalities: dict[str, np.ndarray | None], upper_bounds: dict) -> dict:
    """Score all canonical modalities from one shared descriptive proxy path."""
    if set(modalities) != set(MODALITY_ORDER):
        raise ValueError("modalities must contain exactly the canonical modality keys")
    present = {name: values for name, values in modalities.items() if values is not None}
    multimodal = describe_multimodal_window(present) if set(present) == set(MODALITY_ORDER) else {}
    return {
        name: score_modality_quality(
            name,
            None if values is None else describe_signal(values) | multimodal.get(name, {}),
            upper_bounds[name],
        )
        for name, values in modalities.items()
    }


def describe_signal(values) -> dict[str, float]:
    """Return threshold-free signal descriptors for natural-quality auditing."""
    x = np.asarray(values, dtype=float)
    sample_count = int(x.shape[0]) if x.ndim else int(x.size)
    channel_count = int(x.shape[1]) if x.ndim > 1 else 1
    flat = x.reshape(-1)
    finite = np.isfinite(flat)
    clean = flat[finite]
    result = {
        "sample_count": float(sample_count),
        "channel_count": float(channel_count),
        "missing_ratio": 1.0 - float(finite.mean()) if flat.size else 1.0,
    }
    if clean.size == 0:
        return result | {key: float("nan") for key in (
            "mean", "std", "minimum", "maximum", "range", "median",
            "mad", "zero_step_ratio", "derivative_mad", "max_abs_step",
            "robust_spike_ratio",
        )}

    # Derivatives remain channel-local; channel boundaries must not create steps.
    channels = x.reshape(sample_count, channel_count)
    steps = np.diff(channels, axis=0).reshape(-1)
    steps = steps[np.isfinite(steps)]
    median = float(np.median(clean))
    mad = float(np.median(np.abs(clean - median)))
    robust_scale = 1.4826 * mad
    return result | {
        "mean": float(np.mean(clean)),
        "std": float(np.std(clean)),
        "minimum": float(np.min(clean)),
        "maximum": float(np.max(clean)),
        "range": float(np.ptp(clean)),
        "median": median,
        "mad": mad,
        "zero_step_ratio": float(np.mean(steps == 0)) if steps.size else 1.0,
        "derivative_mad": (
            float(np.median(np.abs(steps - np.median(steps))))
            if steps.size else 0.0
        ),
        "max_abs_step": float(np.max(np.abs(steps))) if steps.size else 0.0,
        "robust_spike_ratio": (
            float(np.mean(np.abs(clean - median) / robust_scale > 8.0))
            if robust_scale > 0 else 0.0
        ),
    }


def assess_quality(values, *, flatline_epsilon: float = 1e-8,
                   clipping_fraction: float = 0.10,
                   spike_z: float = 8.0) -> QualityAssessment:
    """Transparent modality-agnostic foundation quality score.

    Thresholds are smoke-test defaults, not frozen scientific thresholds.
    """
    x = np.asarray(values, dtype=float)
    if x.size == 0:
        return QualityAssessment(0.0, ("unavailable",), {"missing_ratio": 1.0})
    finite = np.isfinite(x)
    missing = 1.0 - float(finite.mean())
    clean = x[finite]
    failures: list[str] = []
    if missing > 0:
        failures.append("missing_samples")
    if clean.size == 0:
        return QualityAssessment(0.0, tuple(failures), {"missing_ratio": missing})
    spread = float(np.ptp(clean))
    flatline = float(np.std(clean) <= flatline_epsilon)
    if flatline:
        failures.append("flatline")
    lo, hi = float(clean.min()), float(clean.max())
    clipped = float(((clean == lo) | (clean == hi)).mean()) if spread > 0 else 1.0
    if spread > 0 and clipped >= clipping_fraction:
        failures.append("clipping")
    median = float(np.median(clean))
    mad = float(np.median(np.abs(clean - median)))
    spike_ratio = 0.0 if mad == 0 else float((np.abs(clean - median) / (1.4826 * mad) > spike_z).mean())
    if spike_ratio > 0:
        failures.append("spikes")
    penalty = min(1.0, missing + 0.55 * flatline + 0.25 * min(1.0, clipped)
                  + 0.20 * min(1.0, spike_ratio * 10))
    return QualityAssessment(round(1.0 - penalty, 6), tuple(failures), {
        "missing_ratio": missing, "flatline": flatline,
        "clipping_ratio": clipped, "spike_ratio": spike_ratio,
    })
