"""Offset-invariant, resolution-scale synthetic post-export perturbations."""
import numpy as np

LEVELS = {'low': (20., 1.), 'medium': (10., 2.), 'high': (0., 4.)}
RESOLUTION = {'acc': 1., 'eda': .0009, 'temp': .02, 'bvp': None}


def inject_sensor_noise(values, modality, level, *, seed, resolution=None):
    """Return perturbed values and physical-dose descriptors; never clip or quantize.

    The direction is Gaussian, centered per channel and normalized to exact RMS.
    It is not iid Gaussian after these constraints and is not an ADC simulator.
    Explicit resolution overrides support consistent positive unit conversions.
    """
    if modality not in RESOLUTION or level not in LEVELS:
        raise ValueError('Unknown sensor or planned noise level')
    values = np.asarray(values, dtype=float)
    was_vector = values.ndim == 1
    x = values[:, None] if was_vector else values
    if x.ndim != 2 or len(x) < 2 or not np.isfinite(x).all():
        raise ValueError('Expected finite native sample-by-channel values')
    if x.shape[1] != (3 if modality == 'acc' else 1):
        raise ValueError('Wrong native channel count')
    quantum = RESOLUTION[modality] if resolution is None else resolution
    if quantum is not None and (not np.isfinite(quantum) or quantum <= 0):
        raise ValueError('Resolution must be finite and positive')
    target_snr, multiplier = LEVELS[level]
    centered_power = float(np.mean((x - x.mean(axis=0)) ** 2))
    temporal_sigma = float(np.sqrt(centered_power / 10 ** (target_snr / 10)))
    floor = multiplier * quantum if quantum is not None else 0.
    sigma = max(temporal_sigma, floor)
    if sigma == 0:
        raise ValueError('Constant BVP has no documented native-unit noise scale')
    noise = np.random.default_rng(seed).normal(size=x.shape)
    noise -= noise.mean(axis=0)
    rms = float(np.sqrt(np.mean(noise ** 2)))
    if rms == 0:
        raise RuntimeError('Degenerate noise direction')
    noise *= sigma / rms
    result = x + noise
    metadata = {'modality': modality, 'level': level, 'target_temporal_snr_db': target_snr,
                'centered_signal_power': centered_power, 'resolution_native_units': quantum,
                'resolution_multiplier': multiplier, 'resolution_floor_sigma': floor,
                'resolution_floor_active': floor > temporal_sigma,
                'sigma_native_units': sigma,
                'realized_rms_native_units': float(np.sqrt(np.mean((result - x) ** 2))),
                'effective_temporal_snr_db': float(10 * np.log10(centered_power / sigma ** 2)) if centered_power else None,
                'constant_source': centered_power == 0,
                'clipped': False, 'requantized': False}
    return result[:, 0] if was_vector else result, metadata


def paired_sensor_controls(clean, first, second, level, *, first_seed, second_seed):
    """Match the first corruption exactly; ambiguous adds only the second one."""
    if set(clean) != set(RESOLUTION) or first == second:
        raise ValueError('Expected four modalities and two distinct targets')
    first_values, first_dose = inject_sensor_noise(clean[first], first, level, seed=first_seed)
    second_values, second_dose = inject_sensor_noise(clean[second], second, level, seed=second_seed)
    single = {m: np.asarray(clean[m], float).copy() for m in clean}
    single[first] = first_values.copy()
    ambiguous = {m: values.copy() for m, values in single.items()}
    ambiguous[second] = second_values
    return single, ambiguous, {first: first_dose, second: second_dose}
