from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Literal


@dataclass(frozen=True)
class ModalitySpec:
    name: str
    units: str
    channels: int
    role: str


@dataclass(frozen=True)
class ModalityEvidence:
    modality: str
    quality: float
    influence: float
    interaction: float
    failures: tuple[str, ...]


@dataclass(frozen=True)
class ModalityQuality:
    modality: str
    score: float
    status: Literal["present", "degraded", "unavailable"]
    indicator_severity: dict[str, float]
    exceeded_indicators: tuple[str, ...]


@dataclass(frozen=True)
class GuardDecision:
    decision: Literal["keep", "abstain"]
    predicted_class: int
    confidence: float
    interaction_score: float
    guard_score: float
    threshold: float
    culprit_modality: str | None
    explanation: str
    evidence: tuple[ModalityEvidence, ...]

    def as_dict(self) -> dict:
        return asdict(self)
