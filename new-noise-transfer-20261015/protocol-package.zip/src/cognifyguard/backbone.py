from __future__ import annotations

import hashlib
import json
from pathlib import Path

import torch
from torch import nn

MODALITY_ORDER = ("eda", "bvp", "temp", "acc")
INPUT_CHANNELS = {"eda": 1, "bvp": 1, "temp": 1, "acc": 3}


class NativeRateEncoder(nn.Module):
    def __init__(self, input_channels: int, embedding_dim: int = 128):
        super().__init__()
        layers = []
        channels = (input_channels, 32, 64, embedding_dim)
        kernels = (7, 5, 3)
        for source, target, kernel in zip(channels[:-1], channels[1:], kernels, strict=True):
            layers.extend([
                nn.Conv1d(source, target, kernel, padding=kernel // 2),
                nn.GroupNorm(num_groups=min(8, target), num_channels=target),
                nn.GELU(),
            ])
        self.network = nn.Sequential(*layers)
        self.pool = nn.AdaptiveAvgPool1d(1)

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        return self.pool(self.network(values)).squeeze(-1)


class CognifyGuardBackbone(nn.Module):
    def __init__(self, embedding_dim: int = 128, classes: int = 3, dropout: float = 0.2):
        super().__init__()
        self.embedding_dim = embedding_dim
        self.encoders = nn.ModuleDict({
            modality: NativeRateEncoder(INPUT_CHANNELS[modality], embedding_dim)
            for modality in MODALITY_ORDER
        })
        self.modality_identity = nn.Parameter(torch.zeros(len(MODALITY_ORDER), embedding_dim))
        nn.init.normal_(self.modality_identity, std=0.02)
        self.attention = nn.Linear(embedding_dim, 1)
        self.classifier = nn.Sequential(
            nn.LayerNorm(embedding_dim), nn.Linear(embedding_dim, embedding_dim),
            nn.GELU(), nn.Dropout(dropout), nn.Linear(embedding_dim, classes),
        )

    def encode_modalities(self, modalities: dict[str, torch.Tensor]) -> torch.Tensor:
        missing_keys = set(MODALITY_ORDER) - set(modalities)
        if missing_keys:
            raise ValueError(f"missing modality contract keys: {sorted(missing_keys)}")
        embeddings = []
        for index, modality in enumerate(MODALITY_ORDER):
            encoded = self.encoders[modality](modalities[modality])
            encoded = encoded + self.modality_identity[index]
            embeddings.append(encoded)
        return torch.stack(embeddings, dim=1)

    def classify_embeddings(
        self,
        stacked: torch.Tensor,
        presence: dict[str, torch.Tensor],
        *,
        return_attention: bool = False,
    ):
        missing_keys = set(MODALITY_ORDER) - set(presence)
        if missing_keys:
            raise ValueError(f"missing modality contract keys: {sorted(missing_keys)}")
        masks = [
            presence[modality].to(dtype=torch.bool, device=stacked.device).reshape(-1)
            for modality in MODALITY_ORDER
        ]
        available = torch.stack(masks, dim=1)
        if torch.any(~available.any(dim=1)):
            raise ValueError("at least one modality must be present for every sample")
        stacked = torch.where(available[:, :, None], stacked, torch.zeros_like(stacked))
        attention_logits = self.attention(stacked).squeeze(-1)
        attention_logits = attention_logits.masked_fill(~available, float("-inf"))
        weights = torch.softmax(attention_logits, dim=1)
        fused = torch.sum(stacked * weights.unsqueeze(-1), dim=1)
        logits = self.classifier(fused)
        return (logits, weights) if return_attention else logits

    def forward(
        self,
        modalities: dict[str, torch.Tensor],
        presence: dict[str, torch.Tensor],
        *,
        return_attention: bool = False,
    ):
        stacked = self.encode_modalities(modalities)
        return self.classify_embeddings(
            stacked, presence, return_attention=return_attention
        )


def architecture_signature(model: nn.Module) -> str:
    specification = [
        (name, tuple(parameter.shape), str(parameter.dtype))
        for name, parameter in model.state_dict().items()
    ]
    return hashlib.sha256(json.dumps(specification).encode()).hexdigest()


def load_checkpoint_strict(model: nn.Module, checkpoint_path: str | Path) -> dict:
    payload = torch.load(checkpoint_path, map_location="cpu", weights_only=True)
    state = payload["model_state"] if "model_state" in payload else payload
    model.load_state_dict(state, strict=True)
    return payload
