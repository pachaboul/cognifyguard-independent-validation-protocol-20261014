import numpy as np
from itertools import product


def paired_t_power(effect_dz, *, n_participants=15, alpha=0.05, two_sided=True):
    """Normal-theory planning power for a paired participant-level contrast."""
    from scipy import stats

    if n_participants < 2:
        raise ValueError("at least two participants are required")
    if not 0 < alpha < 1:
        raise ValueError("alpha must be in (0, 1)")
    effect = abs(float(effect_dz))
    degrees_of_freedom = n_participants - 1
    noncentrality = effect * np.sqrt(n_participants)
    if two_sided:
        critical = stats.t.ppf(1.0 - alpha / 2.0, degrees_of_freedom)
        return float(
            stats.nct.cdf(-critical, degrees_of_freedom, noncentrality)
            + stats.nct.sf(critical, degrees_of_freedom, noncentrality)
        )
    critical = stats.t.ppf(1.0 - alpha, degrees_of_freedom)
    return float(stats.nct.sf(critical, degrees_of_freedom, noncentrality))


def minimum_detectable_paired_effect(
    *, target_power, n_participants=15, alpha=0.05, two_sided=True
):
    from scipy import optimize

    if not 0 < target_power < 1:
        raise ValueError("target power must be in (0, 1)")
    def objective(effect: float) -> float:
        return paired_t_power(
            effect,
            n_participants=n_participants,
            alpha=alpha,
            two_sided=two_sided,
        ) - target_power
    upper = 1.5
    if objective(upper) < 0:
        raise ValueError("target power is not reached within the supported effect range")
    return float(optimize.brentq(objective, 0.0, upper))


def participant_bootstrap_mean_ci(values, *, repetitions=10000, seed=314159, level=0.95):
    values = np.asarray(values, dtype=float)
    if values.ndim != 1 or values.size < 2 or not np.isfinite(values).all():
        raise ValueError("bootstrap values must be a finite 1D array with at least two participants")
    if repetitions < 100:
        raise ValueError("at least 100 bootstrap repetitions are required")
    if not 0 < level < 1:
        raise ValueError("confidence level must be in (0, 1)")
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, values.size, size=(repetitions, values.size))
    means = values[indices].mean(axis=1)
    alpha = (1.0 - level) / 2.0
    low, high = np.quantile(means, [alpha, 1.0 - alpha])
    return {
        "mean": float(values.mean()),
        "ci_low": float(low),
        "ci_high": float(high),
        "confidence_level": float(level),
        "repetitions": int(repetitions),
        "seed": int(seed),
        "n_participants": int(values.size),
    }


def exact_paired_sign_flip_pvalue(differences):
    differences = np.asarray(differences, dtype=float)
    if differences.ndim != 1 or differences.size < 2 or not np.isfinite(differences).all():
        raise ValueError("paired differences must be a finite 1D participant array")
    nonzero = differences[differences != 0]
    if nonzero.size == 0:
        return 1.0
    if nonzero.size > 20:
        raise ValueError("exact sign-flip test is limited to 20 nonzero pairs")
    observed = abs(float(nonzero.mean()))
    null = np.asarray([
        np.mean(nonzero * np.asarray(signs))
        for signs in product((-1.0, 1.0), repeat=nonzero.size)
    ])
    return float(np.mean(np.abs(null) >= observed - 1e-15))


def paired_standardized_mean_difference(differences):
    """Paired standardized effect d_z: mean difference / sample SD."""
    differences = np.asarray(differences, dtype=float)
    if differences.ndim != 1 or differences.size < 2 or not np.isfinite(differences).all():
        raise ValueError("paired differences must be a finite 1D participant array")
    standard_deviation = differences.std(ddof=1)
    if standard_deviation == 0:
        raise ValueError("standardized paired effect is undefined for zero variance")
    return float(differences.mean() / standard_deviation)


def paired_effect_bootstrap_ci(
    differences, *, repetitions=10000, seed=314159, level=0.95
):
    """Participant bootstrap CIs for raw paired difference and paired d_z."""
    differences = np.asarray(differences, dtype=float)
    if differences.ndim != 1 or differences.size < 2 or not np.isfinite(differences).all():
        raise ValueError("paired differences must be a finite 1D participant array")
    if repetitions < 100:
        raise ValueError("at least 100 bootstrap repetitions are required")
    if not 0 < level < 1:
        raise ValueError("confidence level must be in (0, 1)")
    observed_dz = paired_standardized_mean_difference(differences)
    rng = np.random.default_rng(seed)
    samples = differences[
        rng.integers(0, differences.size, size=(repetitions, differences.size))
    ]
    sample_means = samples.mean(axis=1)
    sample_sd = samples.std(axis=1, ddof=1)
    finite = sample_sd > 0
    sample_dz = sample_means[finite] / sample_sd[finite]
    if sample_dz.size < repetitions * 0.95:
        raise ValueError("too many zero-variance bootstrap samples for a stable d_z interval")
    alpha = (1.0 - level) / 2.0
    raw_low, raw_high = np.quantile(sample_means, [alpha, 1.0 - alpha])
    dz_low, dz_high = np.quantile(sample_dz, [alpha, 1.0 - alpha])
    return {
        "mean_paired_difference": float(differences.mean()),
        "mean_ci_low": float(raw_low),
        "mean_ci_high": float(raw_high),
        "paired_dz": observed_dz,
        "paired_dz_ci_low": float(dz_low),
        "paired_dz_ci_high": float(dz_high),
        "confidence_level": float(level),
        "repetitions": int(repetitions),
        "seed": int(seed),
        "n_participants": int(differences.size),
    }


def holm_adjust(pvalues):
    pvalues = np.asarray(pvalues, dtype=float)
    if pvalues.ndim != 1 or not np.isfinite(pvalues).all():
        raise ValueError("p-values must be a finite 1D array")
    if ((pvalues < 0) | (pvalues > 1)).any():
        raise ValueError("p-values must be in [0, 1]")
    order = np.argsort(pvalues, kind="stable")
    adjusted = np.empty_like(pvalues)
    running = 0.0
    total = len(pvalues)
    for rank, index in enumerate(order):
        running = max(running, (total - rank) * pvalues[index])
        adjusted[index] = min(1.0, running)
    return adjusted


def culprit_localization_metrics(true_modalities, predicted_culprits):
    """Report total localization and resolved-only precision without conflating them."""
    truth = list(true_modalities)
    predicted = list(predicted_culprits)
    if not truth or len(truth) != len(predicted):
        raise ValueError("truth and predictions must be non-empty and aligned")
    resolved = np.asarray([bool(value) for value in predicted], dtype=bool)
    correct = np.asarray([actual == estimate for actual, estimate in zip(truth, predicted)], dtype=bool)
    return {
        "total_top1_accuracy": float(correct.mean()),
        "unresolved_rate": float((~resolved).mean()),
        "resolved_coverage": float(resolved.mean()),
        "resolved_only_top1_accuracy": float(correct[resolved].mean()) if resolved.any() else None,
        "samples": len(truth),
    }


def participant_first_seed_mean(rows, *, participant_key="participant_id", seed_key="seed", value_key="value"):
    """Average repeated seeds within a participant before cohort aggregation."""
    grouped = {}
    for row in rows:
        participant = row[participant_key]
        seed = row[seed_key]
        key = (participant, seed)
        if key in grouped:
            raise ValueError(f"duplicate participant-seed record: {key}")
        grouped[key] = float(row[value_key])
    by_participant = {}
    for (participant, _seed), value in grouped.items():
        by_participant.setdefault(participant, []).append(value)
    return {participant: float(np.mean(values)) for participant, values in by_participant.items()}
