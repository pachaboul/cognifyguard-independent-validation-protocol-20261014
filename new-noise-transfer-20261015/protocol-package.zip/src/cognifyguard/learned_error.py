"""Exploratory participant-weighted post-hoc logistic error predictors."""

import json

import numpy as np
from scipy.optimize import minimize
from scipy.special import expit

MODALITIES = ("acc", "bvp", "eda", "temp")
VARIANTS = ("confidence", "confidence_quality", "confidence_quality_influence")


def features(rows, variant):
    if variant not in VARIANTS:
        raise ValueError("Unknown feature variant")
    result = []
    for row in rows:
        prediction = int(row["prediction"])
        if prediction not in (0, 1, 2):
            raise ValueError("Expected three-class predictions")
        values = [1 - float(row["confidence"])] + [float(prediction == c) for c in range(3)]
        if variant != "confidence":
            quality = json.loads(row["qualities"])
            deficits = [1 - float(quality[m]) for m in MODALITIES]
            values += deficits
        if variant == "confidence_quality_influence":
            influence = json.loads(row["influences"])
            positive = np.maximum([float(influence[m]) for m in MODALITIES], 0)
            positive = positive / positive.sum() if positive.sum() else positive
            values += positive.tolist() + (positive * deficits).tolist()
        result.append(values)
    array = np.asarray(result, dtype=float)
    if array.ndim != 2 or not np.isfinite(array).all():
        raise ValueError("Invalid features")
    return array


def group_weights(groups):
    groups = np.asarray(groups)
    unique, counts = np.unique(groups, return_counts=True)
    if not len(unique):
        raise ValueError("Empty training groups")
    lookup = dict(zip(unique, counts))
    return np.array([1 / (len(unique) * lookup[g]) for g in groups])


def objective(parameters, x, y, weights, penalty):
    logits = parameters[0] + x @ parameters[1:]
    residual = weights * (expit(logits) - y)
    loss = np.sum(weights * (np.logaddexp(0, logits) - y * logits))
    loss += penalty * np.sum(parameters[1:] ** 2) / 2
    gradient = np.r_[residual.sum(), x.T @ residual + penalty * parameters[1:]]
    return float(loss), gradient


def fit(x, y, groups, penalty):
    x, y = np.asarray(x, float), np.asarray(y, float)
    if (
        x.ndim != 2 or len(x) != len(y) or len(y) != len(groups)
        or not np.isfinite(x).all() or not np.isin(y, [0, 1]).all() or penalty <= 0
    ):
        raise ValueError("Invalid training data or penalty")
    weights = group_weights(groups)
    mean = weights @ x
    scale = np.sqrt(weights @ ((x - mean) ** 2))
    scale[scale < 1e-8] = 1
    standardized = (x - mean) / scale
    prevalence = float(y[0]) if np.all(y == y[0]) else float(weights @ y)
    parameters = np.zeros(x.shape[1] + 1)
    parameters[0] = np.log(np.clip(prevalence, 1e-8, 1 - 1e-8) / np.clip(1 - prevalence, 1e-8, 1))
    status = "constant_target"
    if 0 < prevalence < 1:
        fitted = minimize(objective, parameters, args=(standardized, y, weights, penalty),
                          jac=True, method="L-BFGS-B", options={"maxiter": 500, "ftol": 1e-12})
        if not fitted.success or not np.isfinite(fitted.x).all():
            raise RuntimeError(f"Logistic fit failed: {fitted.message}")
        parameters = fitted.x
        status = "converged"
    return {"mean": mean.tolist(), "scale": scale.tolist(), "parameters": parameters.tolist(),
            "penalty": penalty, "status": status, "training_groups": sorted(set(groups)),
            "constant_probability": prevalence if status == "constant_target" else None}


def predict(model, x):
    x = np.asarray(x, float)
    if x.ndim != 2 or x.shape[1] != len(model["mean"]) or not np.isfinite(x).all():
        raise ValueError("Invalid prediction features")
    if model["constant_probability"] is not None:
        return np.full(len(x), model["constant_probability"])
    parameters = np.asarray(model["parameters"])
    return expit(parameters[0] + ((x - model["mean"]) / model["scale"]) @ parameters[1:])
