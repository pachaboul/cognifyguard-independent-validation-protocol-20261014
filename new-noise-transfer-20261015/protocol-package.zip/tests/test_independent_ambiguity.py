import numpy as np
import pytest

from cognifyguard.independent_ambiguity import (
    CHANNELS, RATES, canonical_participant, gate_decision, joint_conclusion,
    modality_pair, noise_seed, paired_interval, parse_start, read_e4_channel, select_sources,
    synchronized_windows,
)


def signals():
    return {m: (1000., rate, np.ones((30 * rate, CHANNELS[m]))) for m, rate in RATES.items()}


def test_native_windows_preserve_units_and_never_impute():
    data = signals()
    data['acc'][2][:] = 64
    data['eda'][2][40] = np.nan
    windows = list(synchronized_windows(data))
    assert [start for start, _ in windows] == [1000, 1020]
    assert windows[0][1]['acc'].shape == (320, 3)
    assert windows[0][1]['acc'].dtype == np.float32
    assert np.all(windows[0][1]['acc'] == 64)


@pytest.mark.parametrize('problem', ['rate', 'shape', 'offset'])
def test_invalid_recording_is_rejected(problem):
    data = signals()
    start, rate, values = data['acc']
    if problem == 'rate':
        rate = 31
    elif problem == 'shape':
        values = values[:, :2]
    else:
        start += .01
    data['acc'] = (start, rate, values)
    with pytest.raises(ValueError):
        list(synchronized_windows(data))


def test_alignment_clips_to_common_extent():
    data = signals()
    data['eda'] = (1001., 4, np.ones((116, 1)))
    assert [start for start, _ in synchronized_windows(data)] == [1001, 1011]


def test_split_recordings_are_one_unit_and_sources_order_independent():
    assert canonical_participant('f14_a') == canonical_participant('f14_b') == 'f14'
    rows = [{'participant': 'f14', 'recording': f'f14_{suffix}', 'start': float(i * 10)}
            for suffix in ('a', 'b') for i in range(20)]
    selected = select_sources(rows)
    assert selected == select_sources(rows[::-1]) and len(selected) == 24
    assert select_sources(rows[:23]) == []
    with pytest.raises(ValueError):
        select_sources(rows + rows[:1])
    pairs = [modality_pair(i) for i in range(24)]
    assert len(set(pairs)) == 12 and all(pairs.count(p) == 2 for p in set(pairs))


def test_seeds_separate_regimes_replicates_and_recording_parts():
    seeds = {noise_seed('f14', part, 10., replicate, regime, m)
             for part in ('f14_a', 'f14_b') for replicate in (7, 42, 101)
             for regime in ('single', 'ambiguous') for m in RATES}
    assert len(seeds) == 48
    assert parse_start('1970-01-01T00:00:00Z') == parse_start('0') == 0


def test_threshold_equality_rejects_and_gate_cannot_invent_a_culprit():
    model = {'mean': [0.] * 8, 'scale': [1.] * 8, 'parameters': [0.] * 9,
             'constant_probability': .5, 'rejection_threshold': .5}
    q = {'acc': .1, 'bvp': 1., 'eda': 1., 'temp': 1.}
    assert gate_decision(q, model)['quality_only'] == 'acc'
    assert gate_decision(q, model)['learned_quality_gate'] == ''
    model['rejection_threshold'] = .6
    assert gate_decision(q, model)['learned_quality_gate'] == 'acc'
    q['bvp'] = .1
    assert gate_decision(q, model)['learned_quality_gate'] == ''


def test_success_requires_benefit_and_preserved_localization():
    benefit = [-.40, -.41, -.42, -.43, -.44]
    retained = [-.01, -.02, -.01, -.02, -.01]
    assert joint_conclusion(benefit, retained)['joint_success']
    assert not joint_conclusion(benefit, [-.15, -.16, -.17, -.18, -.19])['joint_success']
    assert not joint_conclusion([.01, .02, .03, .04, .05], retained)['joint_success']


def test_zero_variance_and_small_samples_never_claim_certainty():
    assert paired_interval([-.2, -.2])['method'] == 'uninformative'
    assert not joint_conclusion([-.5], [0])['joint_success']
    with pytest.raises(ValueError):
        paired_interval([np.nan])
    with pytest.raises(ValueError):
        paired_interval([1.01])
    with pytest.raises(ValueError):
        joint_conclusion([-.5, -.4], [0])


def test_e4_csv_reader_preserves_native_values_and_utc(tmp_path):
    path = tmp_path / 'ACC.csv'
    path.write_text('1970-01-01 00:00:00,1970-01-01 00:00:00,1970-01-01 00:00:00\n32,32,32\n64,0,-64\n,1,2\n')
    start, rate, values = read_e4_channel(path, 'acc')
    assert start == 0 and rate == 32
    np.testing.assert_array_equal(values[0], [64, 0, -64])
    assert np.isnan(values[1, 0])


@pytest.mark.parametrize('contents', ['0\n4\n', '0\n8\n1\n', '0\n4\n1,2\n'])
def test_e4_csv_invalid_layout_rejected(tmp_path, contents):
    path = tmp_path / 'EDA.csv'
    path.write_text(contents)
    with pytest.raises(ValueError):
        read_e4_channel(path, 'eda')
