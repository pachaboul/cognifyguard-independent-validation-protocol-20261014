import numpy as np
import pytest

from cognifyguard.retention_constrained import select_threshold


def test_retention_budget_applies_per_participant_not_pooled_only():
    # Participant a would lose its only correct case at the aggressive threshold.
    scores = [.9, .95, .8, .85]
    chosen, candidates = select_threshold(scores, scores, [False, True, False, True],
                                         [True] * 4, [True, False, False, False], ['a', 'a', 'b', 'b'],
                                         maximum_loss=.5)
    assert chosen['threshold'] > .9
    assert chosen['cross_fitted_max_participant_loss'] == 0
    assert any(not row['feasible'] for row in candidates)


def test_refit_drift_cannot_silently_violate_development_constraint():
    chosen, _ = select_threshold([.1, .9], [.8, .9], [False, True], [True, True],
                                 [True, False], ['a', 'a'], maximum_loss=0)
    assert .8 < chosen['threshold'] <= .9
    assert chosen['final_refit_max_participant_loss'] == 0
    assert chosen['conservative_development_reduction'] == 1


def test_equal_risk_correct_and_ambiguous_requires_reject_none_at_zero_budget():
    chosen, _ = select_threshold([.5, .5], [.5, .5], [False, True], [True, True],
                                 [True, False], ['a', 'a'], maximum_loss=0)
    assert chosen['threshold'] > .5
    assert chosen['conservative_development_reduction'] == 0


def test_unresolved_ambiguous_cases_are_not_counted_as_removed_false_assertions():
    chosen, _ = select_threshold([.1, .9], [.1, .9], [False, True], [True, False],
                                 [True, False], ['a', 'a'], maximum_loss=0)
    assert chosen['conservative_development_reduction'] == 0


def test_group_weighting_and_row_permutation_are_invariant():
    cross = np.array([.1, .8, .2, .9, .9])
    regime = np.array([False, True, False, True, True])
    correct = ~regime
    groups = np.array(['a', 'a', 'b', 'b', 'b'])
    a, _ = select_threshold(cross, cross, regime, np.ones(5, bool), correct, groups)
    order = [4, 2, 0, 3, 1]
    b, _ = select_threshold(cross[order], cross[order], regime[order], np.ones(5, bool), correct[order], groups[order])
    assert a == b


def test_level_cells_prevent_a_pooled_budget_hiding_one_level_loss():
    scores = [.1, .7, .9, .95]
    ambiguous = [False, True, False, True]
    correct = [True, False, True, False]
    pooled, _ = select_threshold(scores, scores, ambiguous, [True] * 4, correct,
                                 ['a'] * 4, maximum_loss=.5)
    per_level, _ = select_threshold(scores, scores, ambiguous, [True] * 4, correct,
                                    ['a/low', 'a/low', 'a/high', 'a/high'], maximum_loss=.5)
    assert pooled['threshold'] <= .9 < per_level['threshold']
    assert per_level['cross_fitted_max_participant_loss'] == 0


@pytest.mark.parametrize('scores', [[np.nan, .5], [-.1, .5], [1.1, .5]])
def test_invalid_scores(scores):
    with pytest.raises(ValueError):
        select_threshold(scores, [.1, .5], [False, True], [True, True], [True, False], ['a', 'a'])
