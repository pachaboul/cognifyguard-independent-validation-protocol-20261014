import numpy as np
import pytest

from cognifyguard.sensor_noise import inject_sensor_noise, paired_sensor_controls


def test_celsius_kelvin_origin_does_not_change_noise_dose():
    x = 33 + np.sin(np.arange(40)) * .01
    a, ma = inject_sensor_noise(x, 'temp', 'low', seed=7)
    b, mb = inject_sensor_noise(x + 273.15, 'temp', 'low', seed=7)
    np.testing.assert_allclose(a, b - 273.15, atol=1e-12, rtol=0)
    assert ma['sigma_native_units'] == mb['sigma_native_units'] == .02


def test_acc_raw_counts_to_g_with_resolution_conversion():
    x = np.arange(960, dtype=float).reshape(320, 3) / 20
    a, _ = inject_sensor_noise(x, 'acc', 'medium', seed=42)
    b, _ = inject_sensor_noise(x / 64, 'acc', 'medium', seed=42, resolution=1 / 64)
    np.testing.assert_allclose(a / 64, b, atol=1e-12)


@pytest.mark.parametrize('modality,shape', [('acc', (320, 3)), ('eda', (40, 1)), ('temp', (40, 1)), ('bvp', (640, 1))])
def test_exact_dose_mean_preservation_monotonicity_and_source_immutability(modality, shape):
    x = np.random.default_rng(101).normal(size=shape)
    before = x.copy()
    amplitudes = []
    for level in ('low', 'medium', 'high'):
        y, m = inject_sensor_noise(x, modality, level, seed=7)
        amplitudes.append(m['sigma_native_units'])
        assert np.sqrt(np.mean((y - x) ** 2)) == pytest.approx(m['sigma_native_units'], rel=1e-12)
        np.testing.assert_allclose(y.mean(axis=0), x.mean(axis=0), atol=1e-12)
        again, _ = inject_sensor_noise(x, modality, level, seed=7)
        np.testing.assert_array_equal(y, again)
    assert amplitudes[0] < amplitudes[1] < amplitudes[2]
    np.testing.assert_array_equal(x, before)


def test_constant_sources_have_explicit_sensor_specific_handling():
    for modality, value in [('temp', 33), ('eda', 2)]:
        _, m = inject_sensor_noise(np.full((40, 1), value), modality, 'low', seed=7)
        assert m['constant_source'] and m['resolution_floor_active']
    with pytest.raises(ValueError, match='Constant BVP'):
        inject_sensor_noise(np.ones((640, 1)), 'bvp', 'low', seed=7)


def test_no_silent_hardware_clipping():
    x = np.full((320, 3), 127.)
    y, metadata = inject_sensor_noise(x, 'acc', 'high', seed=7)
    assert np.any(y > 127) and not metadata['clipped']


@pytest.mark.parametrize('values,modality,level', [([np.nan, 1], 'eda', 'low'), ([1], 'eda', 'low'),
                                                  ([1, 2], 'unknown', 'low'), ([1, 2], 'eda', 'mild'),
                                                  ([[1, 2], [3, 4]], 'acc', 'low')])
def test_bad_inputs_rejected(values, modality, level):
    with pytest.raises(ValueError):
        inject_sensor_noise(values, modality, level, seed=7)


def test_matched_controls_add_only_the_second_corruption():
    clean = {'acc': np.ones((320, 3)) * 64, 'eda': np.ones((40, 1)) * 2,
             'temp': np.ones((40, 1)) * 33, 'bvp': np.arange(640.)[:, None]}
    single, ambiguous, dose = paired_sensor_controls(clean, 'eda', 'temp', 'low', first_seed=7, second_seed=42)
    np.testing.assert_array_equal(single['eda'], ambiguous['eda'])
    np.testing.assert_array_equal(single['temp'], clean['temp'])
    assert not np.array_equal(ambiguous['temp'], clean['temp'])
    for m in ('acc', 'bvp'):
        np.testing.assert_array_equal(single[m], ambiguous[m])
    assert set(dose) == {'eda', 'temp'}
    with pytest.raises(ValueError):
        paired_sensor_controls(clean, 'eda', 'eda', 'low', first_seed=7, second_seed=42)
