#!/usr/bin/env python3
"""Exercise the external evaluation chain using generated signals only."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from cognifyguard.faults import inject_fault
from cognifyguard.independent_ambiguity import (
    CHANNELS, RATES, canonical_participant, gate_decision, joint_conclusion,
    modality_pair, noise_seed, select_sources, synchronized_windows,
)
from cognifyguard.quality import score_multimodal_quality


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    protocol_path = ROOT / 'configs/imwut_2026/independent_ambiguity_validation_v1.json'
    protocol = json.loads(protocol_path.read_text())
    model_path = ROOT / protocol['operating_policy']['final_model_artifact']
    model_bytes = model_path.read_bytes()
    if hashlib.sha256(model_bytes).hexdigest() != protocol['operating_policy']['final_model_sha256']:
        raise ValueError('Frozen model SHA mismatch')
    artifact = json.loads(model_bytes)
    decisions, participant_rows = [], []
    for participant_index in range(8):
        participant = f'synthetic_{participant_index}'
        sources = []
        for part in ('a', 'b'):
            recording = participant + '_' + part
            rng = np.random.default_rng(100 + 2 * participant_index + (part == 'b'))
            signals = {}
            for modality, rate in RATES.items():
                samples = np.arange(130 * rate) / rate
                base = {'acc': 64., 'bvp': 0., 'eda': 2., 'temp': 33.}[modality]
                amplitude = {'acc': 2., 'bvp': 30., 'eda': .2, 'temp': .01}[modality]
                values = base + amplitude * np.sin(samples[:, None] * 2 * np.pi)
                values = np.repeat(values, CHANNELS[modality], axis=1)
                values += rng.normal(0, amplitude / 20, values.shape)
                signals[modality] = (1000. + (part == 'b') * 1000, rate, values)
            assert canonical_participant(recording) == participant
            for start, values in synchronized_windows(signals):
                sources.append({'participant': participant, 'recording': recording,
                                'start': start, 'values': values})
        selected = select_sources(sources)
        assert len(selected) == 24 and selected == select_sources(sources[::-1])
        rates = {regime: {policy: [] for policy in ('quality_only', 'learned_quality_gate')}
                 for regime in ('single', 'ambiguous')}
        for index, source in enumerate(selected):
            pair = modality_pair(index)
            for replicate in (7, 42, 101):
                for regime in ('single', 'ambiguous'):
                    values = {m: source['values'][m].copy() for m in RATES}
                    for modality in pair[:1] if regime == 'single' else pair:
                        values[modality] = inject_fault(values[modality], 'additive_noise', {'snr_db': 20.},
                            seed=noise_seed(participant, source['recording'], source['start'], replicate, regime, modality))
                    quality = {m: q.score for m, q in score_multimodal_quality(values, artifact['quality_upper_bounds']).items()}
                    result = gate_decision(quality, artifact['model'])
                    for policy in rates[regime]:
                        rates[regime][policy].append(float(bool(result[policy])) if regime == 'ambiguous'
                                                   else float(result[policy] == pair[0]))
                    decisions.append({'participant': participant, 'recording': source['recording'],
                                      'start': source['start'], 'seed': replicate, 'regime': regime, **result})
        participant_rows.append({'participant': participant,
                                 'ambiguity_difference': float(np.mean(rates['ambiguous']['learned_quality_gate']) - np.mean(rates['ambiguous']['quality_only'])),
                                 'retention_difference': float(np.mean(rates['single']['learned_quality_gate']) - np.mean(rates['single']['quality_only']))})
    conclusion = joint_conclusion([r['ambiguity_difference'] for r in participant_rows],
                                  [r['retention_difference'] for r in participant_rows])
    assert len(decisions) == 1152
    assert all(not r['learned_quality_gate'] or r['learned_quality_gate'] == r['quality_only'] for r in decisions)
    report = {'status': 'PASS_SYNTHETIC_CHAIN_ONLY', 'external_signals_accessed': False,
              'synthetic_participants': 8, 'prediction_records': len(decisions),
              'source_selection_order_invariant': True, 'frozen_model_sha256': hashlib.sha256(model_bytes).hexdigest(),
              'synthetic_conclusion_not_scientific_evidence': conclusion}
    for name, data in [('report.json', report), ('decisions.json', decisions), ('participant_metrics.json', participant_rows)]:
        (args.output / name).write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': report['status'], 'records': len(decisions)}))


if __name__ == '__main__':
    main()
