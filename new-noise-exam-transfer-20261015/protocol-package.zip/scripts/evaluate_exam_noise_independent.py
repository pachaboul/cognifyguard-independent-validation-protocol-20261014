#!/usr/bin/env python3
"""Locked revised-noise transfer; requires verified pre-outcome public deposit."""
import argparse
import csv
import hashlib
import json
import os
import sys
from collections import defaultdict
from datetime import datetime, timezone
from itertools import permutations
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from cognifyguard.independent_ambiguity import gate_decision, joint_conclusion, paired_interval, read_e4_channel, synchronized_windows
from cognifyguard.quality import score_multimodal_quality
from cognifyguard.sensor_noise import paired_sensor_controls
from cognifyguard.statistics import participant_bootstrap_mean_ci

PREP = ROOT / 'reports/imwut_2026/new_noise_independent_exam_preparation_v1'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(out, name, rows):
    path = out / name
    with path.open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    os.chmod(path, 0o600)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--reverse', action='store_true')
    args = parser.parse_args()
    receipt = json.loads((PREP / 'external_deposit_receipt.json').read_text())
    if receipt['status'] != 'VERIFIED_PRE_EVALUATION_GITHUB_DEPOSIT':
        raise ValueError('Verified public deposit required')
    config_path = PREP / 'public_package/protocol.json'
    config = json.loads(config_path.read_text())
    manifest = json.loads((PREP / 'public_package/manifest.json').read_text())
    for relative, digest in manifest.items():
        if sha(PREP / 'public_package' / relative) != digest:
            raise ValueError('Published package changed')
        if relative.startswith(('src/', 'scripts/')) and sha(ROOT / relative) != digest:
            raise ValueError('Executed code differs from published source')
    if sha(PREP / 'public_protocol_package.zip') != receipt['zip_sha256']:
        raise ValueError('Published ZIP changed')
    private_config = json.loads((ROOT / 'configs/imwut_2026/new_noise_independent_exam_v1.json').read_text())
    model_path = ROOT / private_config['model_local_path']
    if sha(model_path) != config['model_sha256']:
        raise ValueError('Transfer model changed')
    artifact = json.loads(model_path.read_text())
    inventory_path = ROOT / private_config['download_inventory_local_path']
    if sha(inventory_path) != config['download_inventory_sha256']:
        raise ValueError('Raw inventory changed')
    inventory = json.loads(inventory_path.read_text())
    for item in inventory['files']:
        path = ROOT.parent / item['path']
        if path.stat().st_size != item['bytes'] or sha(path) != item['sha256']:
            raise ValueError('Independent raw file changed')
    args.output.mkdir(parents=True, exist_ok=False)
    (args.output / 'execution_start.json').write_text(json.dumps({
        'started_at_utc': datetime.now(timezone.utc).isoformat(), 'deposit_commit': receipt['commit_sha'],
        'raw_inventory_sha256': sha(inventory_path), 'protocol_sha256': sha(config_path),
        'script_sha256': sha(Path(__file__)), 'model_sha256': sha(model_path),
        'signal_access_after_deposit': True}, indent=2) + '\n')
    raw = ROOT.parent / 'data/raw_external/wearable-exam-stress-v1-quarantine/data'
    folders = sorted(p for p in raw.iterdir() if p.is_dir())
    if args.reverse:
        folders.reverse()
    decisions, selections, eligibility, metrics = [], [], [], []
    pairs = tuple(permutations(('acc', 'bvp', 'eda', 'temp'), 2))
    for folder in folders:
        pid = folder.name
        candidates, constant = [], 0
        technical_reasons = []
        for recording in sorted(p for p in folder.iterdir() if p.is_dir()):
            recording_id = pid + '/' + recording.name
            try:
                signals = {m: read_e4_channel(recording / (m.upper() + '.csv'), m) for m in ('acc', 'bvp', 'eda', 'temp')}
                windows = synchronized_windows(signals)
                for start, values in windows:
                    bvp = values['bvp'].astype(float)
                    if np.mean((bvp - bvp.mean(axis=0)) ** 2) == 0:
                        constant += 1
                        continue
                    token = f"{config['protocol_id']}|{pid}|{recording_id}|{float(start):.9f}"
                    candidates.append({'start': start, 'recording': recording_id, 'values': values,
                                       'rank': hashlib.sha256(token.encode()).hexdigest()})
            except (ValueError, OSError) as exc:
                technical_reasons.append(recording_id + ':' + str(exc))
        candidates.sort(key=lambda r: r['rank'])
        selected = candidates[:24] if len(candidates) >= 24 else []
        eligibility.append({'participant': pid, 'eligible_windows': len(candidates), 'selected': len(selected),
                            'constant_bvp_excluded': constant, 'reason': ('included' if selected else 'fewer_than_24_windows') + ';' + '|'.join(technical_reasons)})
        if not selected:
            continue
        outcomes = defaultdict(list)
        for index, source in enumerate(selected):
            first, second = pairs[index % 12]
            selections.append({'participant': pid, 'recording': source['recording'], 'start': source['start'], 'source_rank': source['rank'],
                               'first': first, 'second': second})
            for seed in config['noise_seed_replicates']:
                def noise_seed(modality):
                    token = f"{config['protocol_id']}|{pid}|{source['recording']}|{source['start']:.9f}|{seed}|{modality}"
                    return int(hashlib.sha256(token.encode()).hexdigest()[:8], 16)
                for level in config['levels']:
                    single, ambiguous, doses = paired_sensor_controls(source['values'], first, second, level,
                        first_seed=noise_seed(first), second_seed=noise_seed(second))
                    np.testing.assert_array_equal(single[first], ambiguous[first])
                    for regime, values in [('single', single), ('ambiguous', ambiguous)]:
                        quality = {m: q.score for m, q in score_multimodal_quality(values, artifact['quality_upper_bounds']).items()}
                        decision = gate_decision(quality, artifact['model'])
                        for policy in ('quality_only', 'learned_quality_gate'):
                            outcomes[level, regime, seed, policy].append(float(bool(decision[policy])) if regime == 'ambiguous' else float(decision[policy] == first))
                        decisions.append({'participant': pid, 'recording': source['recording'], 'start': source['start'], 'seed': seed, 'level': level,
                                          'regime': regime, 'target': first if regime == 'single' else '',
                                          'qualities': json.dumps(quality, sort_keys=True),
                                          'doses': json.dumps({m: doses[m] for m in (first,)} if regime == 'single' else doses, sort_keys=True),
                                          **decision})
        for level in config['levels']:
            row = {'participant': pid, 'level': level}
            for regime in ('single', 'ambiguous'):
                for policy in ('quality_only', 'learned_quality_gate'):
                    row[regime + '_' + policy] = float(np.mean([np.mean(outcomes[level, regime, seed, policy]) for seed in config['noise_seed_replicates']]))
            metrics.append(row)
    eligibility.sort(key=lambda r: r['participant'])
    write(args.output, 'eligibility.csv', eligibility)
    if not metrics:
        (args.output / 'report.json').write_text(json.dumps({'status': 'NO_TECHNICALLY_ELIGIBLE_PARTICIPANTS', 'eligibility': eligibility}, indent=2) + '\n')
        return
    decisions.sort(key=lambda r: (r['participant'], r['start'], r['seed'], r['level'], r['regime']))
    selections.sort(key=lambda r: (r['participant'], r['source_rank']))
    metrics.sort(key=lambda r: (r['participant'], r['level']))
    participants = sorted({row['participant'] for row in metrics})
    if len(participants) > 10:
        raise ValueError('Exceeded published participant count')
    summary, per_level = [], []
    for level in config['levels']:
        selected = [r for r in metrics if r['level'] == level]
        row = {'level': level, 'participants': len(selected)}
        for name in ('ambiguous_quality_only', 'ambiguous_learned_quality_gate', 'single_quality_only', 'single_learned_quality_gate'):
            row[name] = float(np.mean([r[name] for r in selected]))
        summary.append(row)
        per_level.append({'level': level, 'retention_diagnostic': paired_interval([r['single_learned_quality_gate'] - r['single_quality_only'] for r in selected])})
    ambiguity, retention = [], []
    for pid in participants:
        selected = [r for r in metrics if r['participant'] == pid]
        ambiguity.append(float(np.mean([r['ambiguous_learned_quality_gate'] - r['ambiguous_quality_only'] for r in selected])))
        retention.append(float(np.mean([r['single_learned_quality_gate'] - r['single_quality_only'] for r in selected])))
    primary = joint_conclusion(ambiguity, retention)
    primary['observed_level_retention_guard'] = all(row['single_quality_only'] - row['single_learned_quality_gate'] <= .05 + 1e-12 for row in summary)
    primary['joint_success'] = primary['joint_success'] and primary['observed_level_retention_guard']
    report = {'status': 'COMPLETE_NEW_NOISE_INDEPENDENT_TRANSFER', 'date': '2026-10-15',
              'participants': len(participants), 'source_windows': len(selections), 'records': len(decisions),
              'summary': summary, 'primary_average_over_levels': primary, 'per_level_descriptive': per_level,
              'bootstrap_sensitivity': {name: participant_bootstrap_mean_ci(values, repetitions=10000, seed=20261015)
                                       for name, values in [('ambiguity', ambiguity), ('retention', retention)]} if len(participants) >= 2 else {},
              'deposit_commit': receipt['commit_sha'], 'model_sha256': sha(model_path), 'raw_inventory_sha256': sha(inventory_path),
              'refit_or_retuning': False, 'limitations': config['limits']}
    for name, rows in [('decisions.csv', decisions), ('source_selection.csv', selections), ('participant_metrics.csv', metrics), ('aggregate_summary.csv', summary)]:
        write(args.output, name, rows)
    (args.output / 'report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': report['status'], 'participants': len(participants), 'summary': summary, 'primary': primary}))


if __name__ == '__main__':
    main()
