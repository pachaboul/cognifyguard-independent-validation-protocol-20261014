"""Locked external-control design, without accessing any dataset at import."""
import csv
import hashlib
from datetime import datetime, timezone
from itertools import permutations

import numpy as np
from scipy import stats

from .ambiguity_comparison import quality_features, unique_positive_assertion
from .learned_error import predict
from .localization_comparison import MODALITIES

PROTOCOL_ID = "independent_ambiguity_validation_v1"
RATES = {"acc": 32, "bvp": 64, "eda": 4, "temp": 4}
CHANNELS = {"acc": 3, "bvp": 1, "eda": 1, "temp": 1}


def canonical_participant(recording):
    return recording[:-2] if recording.endswith(("_a", "_b")) else recording


def parse_start(text):
    text = text.strip()
    try:
        value = float(text)
    except ValueError:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00").replace(" UTC", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        value = parsed.timestamp()
    if not np.isfinite(value):
        raise ValueError("Nonfinite start timestamp")
    return value


def read_e4_channel(path, modality):
    """Read documented E4 UTC/raw-rate headers, preserving native signal units."""
    if modality not in RATES:
        raise ValueError("Unknown modality")
    with path.open(newline='') as handle:
        reader = csv.reader(handle)
        try:
            start_header, rate_header = next(reader), next(reader)
        except StopIteration as exc:
            raise ValueError("Missing channel headers") from exc
        if len(start_header) not in (1, CHANNELS[modality]) or len(rate_header) not in (1, CHANNELS[modality]):
            raise ValueError("Wrong header channel count")
        starts = [parse_start(value) for value in start_header]
        rates = [float(value) for value in rate_header]
        if len(set(starts)) != 1 or any(rate != RATES[modality] for rate in rates):
            raise ValueError("Invalid start or sampling rate")
        rows = []
        for row in reader:
            if not row:
                continue
            if len(row) != CHANNELS[modality]:
                raise ValueError("Incomplete channel row")
            rows.append([float(value) if value.strip() else np.nan for value in row])
    if not rows:
        raise ValueError("Empty channel recording")
    return starts[0], rates[0], np.asarray(rows, dtype=np.float32)


def synchronized_windows(signals, seconds=10):
    """signals[m] = (start timestamp, rate, sample-by-channel array)."""
    if set(signals) != set(RATES) or seconds != 10:
        raise ValueError("Expected the frozen four-modality ten-second design")
    arrays = {}
    for m, (start, rate, array) in signals.items():
        array = np.asarray(array, dtype=np.float32)
        if array.ndim == 1:
            array = array[:, None]
        if rate != RATES[m] or not np.isfinite(start) or array.ndim != 2 or array.shape[1] != CHANNELS[m]:
            raise ValueError("Invalid channel header, rate or shape")
        arrays[m] = array
    begin = max(signals[m][0] for m in RATES)
    end = min(signals[m][0] + len(arrays[m]) / RATES[m] for m in RATES)
    offsets = {}
    for m in RATES:
        raw = (begin - signals[m][0]) * RATES[m]
        if abs(raw - round(raw)) > 1e-5:
            raise ValueError("Channel grids are not sample-aligned")
        offsets[m] = round(raw)
    for index in range(max(0, int(np.floor((end - begin) / seconds)))):
        values = {m: arrays[m][offsets[m] + index * seconds * RATES[m]:
                               offsets[m] + (index + 1) * seconds * RATES[m]].copy() for m in RATES}
        if all(len(values[m]) == seconds * RATES[m] and np.isfinite(values[m]).all() for m in RATES):
            yield begin + index * seconds, values


def source_token(participant, recording, start):
    return f"{PROTOCOL_ID}|{participant}|{recording}|{float(start):.9f}"


def source_rank(participant, recording, start):
    return hashlib.sha256(source_token(participant, recording, start).encode()).hexdigest()


def select_sources(rows):
    """Select exactly 24 sources for one canonical participant, independent of scores."""
    if len({row['participant'] for row in rows}) != 1:
        raise ValueError("Expected one nonempty participant group")
    keys = [(r['participant'], r['recording'], r['start']) for r in rows]
    if len(keys) != len(set(keys)):
        raise ValueError("Duplicate source window")
    if len(rows) < 24:
        return []
    return sorted(rows, key=lambda r: source_rank(r['participant'], r['recording'], r['start']))[:24]


def modality_pair(index):
    if index not in range(24):
        raise ValueError("Source index outside fixed design")
    return tuple(permutations(MODALITIES, 2))[index % 12]


def noise_seed(participant, recording, start, replicate, regime, modality):
    if replicate not in (7, 42, 101) or regime not in ('single', 'ambiguous') or modality not in MODALITIES:
        raise ValueError("Unplanned noise condition")
    token = f"{source_token(participant, recording, start)}|{replicate}|{regime}|{modality}"
    return int(hashlib.sha256(token.encode()).hexdigest()[:8], 16)


def gate_decision(qualities, model):
    deficits = [1 - qualities[m] for m in MODALITIES]
    baseline = unique_positive_assertion(deficits)
    risk = float(predict(model, quality_features(qualities)[None, :])[0])
    rejected = risk >= model['rejection_threshold']
    return {'quality_only': baseline, 'learned_quality_gate': '' if rejected else baseline,
            'rejected': rejected, 'risk': risk}


def paired_interval(values):
    values = np.asarray(values, float)
    if values.ndim != 1 or not np.isfinite(values).all() or np.any(np.abs(values) > 1):
        raise ValueError("Expected finite participant differences in [-1,1]")
    result = {'n': len(values), 'mean': float(values.mean()) if len(values) else None,
              'ci_low': -1.0, 'ci_high': 1.0, 'method': 'uninformative'}
    if len(values) >= 2 and values.std(ddof=1) > 0:
        half = float(stats.t.ppf(.975, len(values) - 1) * values.std(ddof=1) / np.sqrt(len(values)))
        result.update(ci_low=max(-1., result['mean'] - half), ci_high=min(1., result['mean'] + half),
                      method='approximate_paired_t_95_percent')
    return result


def joint_conclusion(ambiguity_differences, retention_differences):
    if len(ambiguity_differences) != len(retention_differences):
        raise ValueError("Endpoints must refer to the same participants")
    ambiguity = paired_interval(ambiguity_differences)
    retention = paired_interval(retention_differences)
    ambiguity_pass = ambiguity['ci_high'] < 0
    retention_pass = retention['ci_low'] > -.05
    return {'ambiguity': ambiguity, 'retention': retention, 'ambiguity_pass': ambiguity_pass,
            'retention_pass': retention_pass, 'joint_success': ambiguity_pass and retention_pass}
